Runs on Java 8.71
Find jar in out/artifacts
Click the run.bat file